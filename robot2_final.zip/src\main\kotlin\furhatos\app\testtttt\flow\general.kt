package furhatos.app.testtttt.flow

import furhatos.flow.kotlin.*
import furhatos.gestures.BasicParams
import furhatos.gestures.Gestures
import furhatos.gestures.defineGesture
import furhatos.skills.FurhatAPI
import furhatos.util.*
import java.io.*
import java.net.*


val Idle: State = state {


    init {
        furhat.setVoice(Language.ENGLISH_US, Gender.MALE)

    }

    onEntry {
        try{
            val serverSocket = ServerSocket(1123)
/*
            furhat.say("My IP address is " + Integer.toString(0 + (serverSocket.inetAddress.address[0]))
                    + " dot " + Integer.toString(0 + (serverSocket.inetAddress.address[1]))
                    + " dot " + Integer.toString(0 + (serverSocket.inetAddress.address[2]))
                    + " dot " + Integer.toString(0 + (serverSocket.inetAddress.address[3])))
*/
            while(true) {
                try {
                    val clientSocket = serverSocket.accept()
                    furhat.say("Connection found")
                    //val out = new PrintWriter(clientSocket.getOutputStream(), true);
                    val inn = BufferedReader(InputStreamReader(clientSocket.getInputStream()))
                    while (true) {

                        val proto = inn.readLine()
                        if (proto == "say") {
                            val line = inn.readLine()
                            furhat.say(line)
                        } else if (proto == "face") {
                            val line = inn.readLine()
                            furhat.setTexture(line)
                            furhat.say("I'm " + line)
                        } else if (proto == "gesture") {
                            val line = inn.readLine()

                            if(line == "gazeup") {
                                val gaze = defineGesture("MySmile") {
                                    frame(0.1, 0.5){
                                        BasicParams.BROW_UP_LEFT to 1.0
                                        BasicParams.BROW_UP_RIGHT to 1.0
                                        BasicParams.LOOK_UP to 1.0
                                    }
                                    frame(0.8, 1.0){
                                        BasicParams.LOOK_UP to 0.0
                                    }
                                    frame(1.0, 1.2){
                                        BasicParams.LOOK_UP to 1.0
                                    }
                                    reset(10.0)
                                }
                                furhat.gesture(gaze)
                                //furhat.gesture(Gestures.BrowRaise, async=true)
                                //furhat.glance(FurhatAPI.GazeLocationTarget.UP, 2000)
                            }else if(line == "smile") {
                                furhat.gesture(Gestures.BigSmile)
                            }else if(line == "anger") {
                                furhat.gesture(Gestures.ExpressAnger)
                            }
                        }

                    }
                    clientSocket.close()
                } catch (e: IOException) {
                    furhat.say("An exception occurred")
                    furhat.say(e.toString())
                }
            }
            serverSocket.close()
        } catch (e: IOException) {
            furhat.say("An exception occurred 2")
            furhat.say(e.toString())
        }
    }

    onUserEnter {
        furhat.attend(it)
        furhat.say("QWERASDF")
    }
}
